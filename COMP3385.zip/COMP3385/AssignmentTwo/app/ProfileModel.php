<?php
class Profile Model extends Observable_Model
{
  public function getAll() : array
  {
    return[];
  }

  public function getRecord(string $id): array
  {
    return [];
  }
}


 ?>
