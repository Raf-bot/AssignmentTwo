<?php

namespace Work

class FrontController extends FrontController_Abstract
{

  public static function run()
  {
    $controller = new FrontController();
    $controller->init();
    $controller->handleRequest();
  }

  protected function init()
  {

  }

  protected function handleRequest
  {
    $request = $_POST;
    $handler = RequestHandlerFactory::makeRequestHandler($request['request']);
    $context = new CommandContext();
    if ($handler->execute($context) == false)
    {

    }
  }

}


















 ?>
