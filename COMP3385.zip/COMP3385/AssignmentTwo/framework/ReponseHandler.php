<?php

namespace Work

class ReponseHandler implements ResponseHandler_Interface
{

  protected body = [];

  public function __construct (ReponseHeader $head, ReponseState $state, ReponseLogger $Log)
  {
    $this->body['header'] = $head;
    $this->body['state'] = $state;
    $this->body['log'] = $log;

  }

  public function giveHeader() : ReponseHeader;
  {
    return clone $this->body['header'];
  }

  public function giveState() : ReponseState;
  {
    return clone $this->body['state'];
  }

  public function giveState() : ReponseLogger;
  {
      return clone $this->body['log'];
  }

}


 ?>
