<?php

namespace Work

interface Reponse
{

  public function AddEntries(array $entries): bool;

  public function showEntry(int $i) : string;

  public function showEntries(int $start, int $end): string;
}
