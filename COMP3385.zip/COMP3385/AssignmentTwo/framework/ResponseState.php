<?php

namespace Work

class ReponseState implements ResponseHandler_Interface
{
  public function giveHeader() : ReponseHeader;

  public function giveState() : ReponseState;

  public function giveState() : ReponseLogger;
}

 ?>
